#include <Arduino.h>
#include <SPI.h>

// 3-bit opcodes in top bits of first byte
enum : uint8_t {
  OP_SRAM0 = 0b000,   // payload = [addr16 | data16]
  OP_SRAM1 = 0b001,
  OP_FTW0  = 0b100,   // NCO0 FTW commit
  OP_FTW1  = 0b101,   // NCO1 FTW commit
};

static SPIClass SPIbus(FSPI);
static int PIN_SCK=-1, PIN_MOSI=-1, PIN_CS=-1;
static uint32_t SPI_HZ = 1000000;         // simple, conservative clock

static inline void cs_low()  { digitalWrite(PIN_CS, LOW); }
static inline void cs_high() { digitalWrite(PIN_CS, HIGH); }

static inline void send_frame5(const uint8_t f[5]) {
  cs_low();
  SPIbus.transfer(f[0]);
  SPIbus.transfer(f[1]);
  SPIbus.transfer(f[2]);
  SPIbus.transfer(f[3]);
  SPIbus.transfer(f[4]);
  cs_high();
  delayMicroseconds(20);                 // small gap; keeps slave comfy
}

static inline void pack_and_send(uint8_t op3, uint32_t payload) {
  uint8_t f[5];
  f[0] = uint8_t((op3 & 0x07) << 5);
  f[1] = uint8_t(payload >> 24);
  f[2] = uint8_t(payload >> 16);
  f[3] = uint8_t(payload >>  8);
  f[4] = uint8_t(payload >>  0);
  send_frame5(f);
}

extern "C" void fpga_spi_setup(int sck, int mosi, int cs, unsigned hz) {
  PIN_SCK = sck; PIN_MOSI = mosi; PIN_CS = cs;
  if (hz) SPI_HZ = hz;
  SPIbus.end();
  SPIbus.begin(PIN_SCK, /*MISO*/ -1, PIN_MOSI, PIN_CS);
  pinMode(PIN_CS, OUTPUT);
  cs_high();
  SPIbus.beginTransaction(SPISettings(SPI_HZ, MSBFIRST, SPI_MODE0));
  Serial.printf("[SPI] SCK=%d MOSI=%d CS=%d, %lu Hz\n", sck, mosi, cs, (unsigned long)SPI_HZ);
}

extern "C" void fpga_write_sram(uint8_t bank, uint16_t addr, uint16_t data) {
  const uint8_t op = bank ? OP_SRAM1 : OP_SRAM0;
  const uint32_t payload = (uint32_t(addr) << 16) | uint32_t(data);
  pack_and_send(op, payload);
}

extern "C" void fpga_set_ftw(uint8_t nco, uint32_t ftw) {
  const uint8_t op = nco ? OP_FTW1 : OP_FTW0;
  delay(2);
  pack_and_send(op, ftw);
  delay(2);
}
