// src/ble.cpp — Nordic UART BLE with STD (unchanged) + NEW ARB state machine.
// STD payload (legacy, unchanged):
//   'S', shape(1), freq_mHz(u32), amp_mVpp(u32), offset_mV(s32), phase_deg(s16), channel(1)
// ARB protocol (new, simple, robust):
//   META: 'A' + channel(1) + freq_mHz(u32)
//   DATA: 'D' + count(u16 LE) + count*u16 LE samples   (use chunks of 60 -> 120 bytes)
//   END : 'Z'  (commit if exactly 1024 samples buffered)

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <string.h>

// ---------- Nordic UART UUIDs ----------
static const char* SVC_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
static const char* RX_UUID  = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"; // write
static const char* TX_UUID  = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"; // notify

// ---------- External wavegen API ----------
extern "C" {
  // IMPORTANT: matches your existing wavegen.cpp (legacy STD layout)
  struct StdParams {
    uint8_t  shape;       // 0=sine,1=square,2=triangle,3=sinc
    uint32_t freq_mHz;
    uint32_t amp_mVpp;
    int32_t  offset_mV;
    int16_t  phase_deg;
    uint8_t  channel;     // 0=A,1=B
  };
  void wavegen_build_std_lut(const StdParams& p);
  void wavegen_build_arb_lut(const uint16_t* in1024, uint8_t channel, uint32_t freq_mHz);
}

static inline const char* chan_name(uint8_t ch){ return (ch & 1) ? "B" : "A"; }

// ---------- BLE globals ----------
static BLEServer*         g_srv = nullptr;
static BLECharacteristic* g_rx  = nullptr;
static BLECharacteristic* g_tx  = nullptr;
static bool g_deviceConnected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override {
    g_deviceConnected = true;
    Serial.println("[BLE] Connected");
  }
  void onDisconnect(BLEServer*) override {
    g_deviceConnected = false;
    Serial.println("[BLE] Disconnected");
    BLEDevice::startAdvertising();
  }
};

// ---------- ARB state (new) ----------
static uint16_t arb_buf[1024];
static uint16_t arb_count = 0;
static uint8_t  arb_channel = 0;
static uint32_t arb_freq_mHz = 0;
static bool     arb_meta_seen = false;

static void arb_reset_state() {
  arb_count = 0;
  arb_channel = 0;
  arb_freq_mHz = 0;
  arb_meta_seen = false;
}

static void arb_commit_if_ready() {
  if (!arb_meta_seen) { Serial.println("[ARB] END without META"); return; }
  if (arb_count != 1024) {
    Serial.printf("[ARB] END but count=%u (need 1024)\n", arb_count);
    return;
  }
  Serial.printf("[ARB] COMMIT ch=%s freq=%lu mHz, samples=1024\n",
                chan_name(arb_channel), (unsigned long)arb_freq_mHz);
  wavegen_build_arb_lut(arb_buf, arb_channel, arb_freq_mHz);
  arb_reset_state();
}

// ---------- RX handler ----------
class RxCallbacks : public BLECharacteristicCallbacks {
  static uint32_t rd_u32_le(const uint8_t* p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
  static uint16_t rd_u16_le(const uint8_t* p){ return (uint16_t)p[0] | ((uint16_t)p[1]<<8); }

  void onWrite(BLECharacteristic* c) override {
    std::string v = c->getValue();
    const uint8_t* d = (const uint8_t*)v.data();
    size_t n = v.size();
    if (n == 0) return;

    // ----- STD (unchanged) -----
    // 'S' + shape(1) + freq_mHz(4) + amp_mVpp(4) + offset_mV(4) + phase_deg(2) + channel(1)
    if (d[0] == 'S') {
      if (n < 17) { Serial.printf("[STD] bad len=%u\n",(unsigned)n); return; }
      StdParams p{};
      size_t i = 1;
      p.shape = d[i++];

      memcpy(&p.freq_mHz,  d+i, 4); i+=4;
      memcpy(&p.amp_mVpp,  d+i, 4); i+=4;
      memcpy(&p.offset_mV, d+i, 4); i+=4;
      memcpy(&p.phase_deg, d+i, 2); i+=2;

      p.channel = d[i++];

      Serial.printf("[STD] ch=%s shape=%u f=%.3fHz vpp=%.3fV ofs=%.3fV ph=%ddeg\n",
        chan_name(p.channel), (unsigned)p.shape,
        p.freq_mHz/1000.0, p.amp_mVpp/1000.0, p.offset_mV/1000.0, (int)p.phase_deg);

      wavegen_build_std_lut(p);
      return;
    }

    // ----- NEW: ARB META -----
    // 'A' + channel(1) + freq_mHz(4)
    if (d[0] == 'A') {
      if (n < 1+1+4) { Serial.printf("[ARB] META bad len=%u\n",(unsigned)n); return; }
      arb_reset_state();
      arb_channel   = d[1];
      arb_freq_mHz  = rd_u32_le(&d[2]);
      arb_meta_seen = true;
      Serial.printf("[ARB] META ch=%s freq=%lu mHz\n", chan_name(arb_channel), (unsigned long)arb_freq_mHz);
      return;
    }

    // ----- NEW: ARB DATA -----
    // 'D' + count(u16 LE) + count*u16 LE samples
    if (d[0] == 'D') {
      if (!arb_meta_seen) { Serial.println("[ARB] DATA before META"); return; }
      if (n < 3) { Serial.printf("[ARB] DATA too short len=%u\n",(unsigned)n); return; }
      uint16_t cnt = rd_u16_le(&d[1]);
      if (n != (size_t)(3 + 2*cnt)) {
        Serial.printf("[ARB] DATA len=%u mism cnt=%u\n",(unsigned)n, cnt);
        return;
      }
      if (arb_count + cnt > 1024) {
        Serial.printf("[ARB] DATA overflow: have=%u add=%u\n", arb_count, cnt);
        return;
      }
      const uint8_t* p = &d[3];
      for (uint16_t i=0;i<cnt;i++,p+=2) {
        arb_buf[arb_count++] = rd_u16_le(p);
      }
      if ((arb_count % 120) == 0 || arb_count == 1024) {
        Serial.printf("[ARB] DATA ok, total=%u\n", arb_count);
      }
      return;
    }

    // ----- NEW: ARB END -----
    if (d[0] == 'Z') {
      arb_commit_if_ready();
      return;
    }

    Serial.printf("[BLE] Unknown payload len=%u (op=0x%02X)\n", (unsigned)n, d[0]);
  }
};

void ble_setup(){
  BLEDevice::init("ESP32-JOE");
  g_srv = BLEDevice::createServer();
  g_srv->setCallbacks(new ServerCallbacks());

  BLEService* svc = g_srv->createService(SVC_UUID);
  g_rx = svc->createCharacteristic(RX_UUID, BLECharacteristic::PROPERTY_WRITE);
  g_tx = svc->createCharacteristic(TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  g_tx->addDescriptor(new BLE2902());

  g_rx->setCallbacks(new RxCallbacks());
  svc->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SVC_UUID);
  adv->setScanResponse(true);
  adv->setMinPreferred(0x06);
  adv->setMinPreferred(0x12);
  BLEDevice::startAdvertising();

  Serial.println("[BLE] Advertising as ESP32-JOE");
}

void ble_loop_pump(){ delay(2); }
