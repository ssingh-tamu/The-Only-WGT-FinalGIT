#include <Arduino.h>

// BLE
void ble_setup();
void ble_loop_pump();

// SPI driver
extern "C" void fpga_spi_setup(int sck, int mosi, int cs, unsigned hz);

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 2000) { delay(10); }
  Serial.println("[BOOT] ESP32-S3 Sender (CS per 5B frame)");

  // ===== S3 PINS (master) =====
  // Do NOT use 19/20 (USB D-/D+).
  const int PIN_SCK  = 11;
  const int PIN_MOSI = 9;
  const int PIN_CS   = 12;
  const unsigned SPI_HZ = 1000000; // 1 MHz to start

  fpga_spi_setup(PIN_SCK, PIN_MOSI, PIN_CS, SPI_HZ);

  ble_setup();

  Serial.println("[INFO] Send via BLE STD/ARB; receiver expects 32 samples then FTW.");
}

void loop() {
  ble_loop_pump();
}
