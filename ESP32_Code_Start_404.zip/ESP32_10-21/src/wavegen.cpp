// src/wavegen.cpp — S3 sender: matches OLD ble.cpp struct layout, no BLE changes needed.

#include <Arduino.h>
#include <math.h>
#include <stdint.h>

// SPI helpers implemented in fpga_spi.cpp
extern "C" {
  void fpga_write_sram(uint8_t bank, uint16_t addr, uint16_t data);
  void fpga_set_ftw(uint8_t nco_index, uint32_t ftw);
}

// *** IMPORTANT ***
// This struct MUST match the layout used by your OLD ble.cpp.
// Order here mirrors the bytes your Python -> BLE path sends:
//   shape, freq_mHz, amp_mVpp, offset_mV, phase_deg, channel
struct StdParams {
  uint8_t  shape;       // 0=sine, 1=square, 2=triangle, 3=sinc
  uint32_t freq_mHz;    // milli-Hz
  uint32_t amp_mVpp;    // mVpp
  int32_t  offset_mV;   // mV
  int16_t  phase_deg;   // degrees
  uint8_t  channel;     // 0=A, 1=B
};

#define NUM_TEST_SAMPLES  1024
#define TEST_ADDR_STRIDE  64

static volatile bool tx_busy = false;

static inline const char* chan_name(uint8_t ch){ return (ch & 1) ? "B" : "A"; }

static inline uint32_t compute_ftw(double f_hz, double fclk_hz){
  if (f_hz < 0) f_hz = 0;
  if (f_hz > fclk_hz/2) f_hz = fclk_hz/2;
  double x = f_hz * (4294967296.0 / fclk_hz); // 2^32
  if (x < 0.0) x = 0.0;
  if (x > 4294967295.0) x = 4294967295.0;
  return (uint32_t)(x + 0.5);
}

// --- waveform primitives ---
static inline double w_sine(double ph){ return sin(2.0 * M_PI * ph); }
static inline double w_square(double ph){ return (fmod(ph,1.0) < 0.5) ? 1.0 : -1.0; }
static inline double w_triangle(double ph){
  double t = ph - floor(ph);
  if (t < 0.25)      return 4.0 * t;
  else if (t < 0.75) return 2.0 - 4.0 * t;
  else               return -4.0 + 4.0 * t;
}
static inline double w_sinc(double ph){
  // Expand phase so we see multiple lobes (e.g., ~±3 lobes)
  const double L = 6.0;                 // try 6 for ~±3 zeros
  double x = (ph - 0.5) * L;
  if (fabs(x) < 1e-12) return 1.0;
  double pix = M_PI * x;
  return sin(pix) / (pix);
}


// ±5 V span → 0..65535 DAC codes
static inline uint16_t phys_to_code(double x_norm, double vpp_V, double ofs_V){
  double v = ofs_V + 0.5 * vpp_V * x_norm;
  double code = (v + 5.0) * (65535.0 / 10.0);
  if (code < 0.0) code = 0.0;
  if (code > 65535.0) code = 65535.0;
  return (uint16_t)(code + 0.5);
}

// hard map: 0=sine, 1=square, 2=triangle, 3=sinc
static inline uint16_t sample_code(uint8_t shape, double ph, double vpp_V, double ofs_V){
  double x;
  switch (shape & 0x03) {
    case 0: x = w_sine(ph);     break;
    case 1: x = w_square(ph);   break;
    case 2: x = w_triangle(ph); break;
    default: // 3
      x = w_sinc(ph);           break;
  }
  return phys_to_code(x, vpp_V, ofs_V);
}

static void send_1024(uint8_t sram_index, uint8_t shape, double phase_off, double vpp_V, double ofs_V){
  // small head-start so the receiver queues transactions
  delay(20);
  for (uint32_t i = 0, addr = 0; i < NUM_TEST_SAMPLES; ++i, addr += TEST_ADDR_STRIDE) {
    double ph = fmod((addr / 65536.0) + phase_off, 1.0);
    uint16_t data = sample_code(shape, ph, vpp_V, ofs_V);
    fpga_write_sram(sram_index, (uint16_t)addr, data);
  }
}

extern "C" void wavegen_build_std_lut(const StdParams& p){
  if (tx_busy) { Serial.println("[TX] busy"); return; }
  tx_busy = true;

  const double fclk_hz = 1000000.0;
  const double f_hz    = ((double)p.freq_mHz) / 1000.0;
  const uint32_t ftw   = compute_ftw(f_hz, fclk_hz);

  const double vpp_V = ((double)p.amp_mVpp) / 1000.0;
  const double ofs_V = ((double)p.offset_mV) / 1000.0;
  const double ph_off = fmod(((double)p.phase_deg) / 360.0, 1.0);
  const uint8_t sram_index = (p.channel & 1) ? 1 : 0;

  Serial.printf("[STD] ch=%s shape=%u f=%.3fHz vpp=%.3fV ofs=%.3fV ph=%.3fdeg\n",
    chan_name(p.channel), (unsigned)p.shape, f_hz, vpp_V, ofs_V, (double)p.phase_deg);

  Serial.printf("[LUT] STD ch=%s FTW=0x%08lX\n", chan_name(p.channel), (unsigned long)ftw);

  send_1024(sram_index, p.shape, ph_off, vpp_V, ofs_V);
  Serial.printf("[TX] sent %u samples\n", (unsigned)NUM_TEST_SAMPLES);

  fpga_set_ftw((p.channel & 1) ? 1 : 0, ftw);
  delay(100); // cooldown to avoid overlapping runs
  tx_busy = false;
}

// Keep ARB available because ble.cpp references it
extern "C" void wavegen_build_arb_lut(const uint16_t* in1024, uint8_t channel, uint32_t freq_mHz){
  if (tx_busy) { Serial.println("[TX] busy"); return; }
  tx_busy = true;

  const double fclk_hz = 1000000.0;
  const double f_hz    = ((double)freq_mHz) / 1000.0;
  const uint32_t ftw   = compute_ftw(f_hz, fclk_hz);
  const uint8_t sram_index = (channel & 1) ? 1 : 0;

  delay(20);
  for (uint32_t i = 0; i < NUM_TEST_SAMPLES; ++i) {
    uint16_t addr = (uint16_t)(i * TEST_ADDR_STRIDE);
    fpga_write_sram(sram_index, addr, in1024[i]);
  }
  Serial.printf("[TX][ARB] sent %u samples\n", (unsigned)NUM_TEST_SAMPLES);

  fpga_set_ftw((channel & 1) ? 1 : 0, ftw);
  delay(100);
  tx_busy = false;
}
