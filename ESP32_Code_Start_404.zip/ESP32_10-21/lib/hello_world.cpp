#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  delay(500);                    // brief pause so USB-CDC enumerates
  Serial.println("Hello, world!");
}

void loop() {
  Serial.println("Still alive...");
  delay(1000);                   // 1 second
}
