#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <string>
#include <utility>
#include <esp_heap_caps.h>
#ifdef ARDUINO_ARCH_ESP32
  #include <esp_task_wdt.h>
#endif

// ======= TOGGLE: actually stream to FPGA over SPI after preview =======
// Set to 1 when you have the FPGA wired. While 0, we do preview only.
#ifndef ENABLE_SPI_STREAM
#define ENABLE_SPI_STREAM 0
#endif

// ---- tiny shared structs (avoid headers to keep this self-contained) ----
struct StdParams {
  uint8_t  shape;         // 0=sine,1=square,2=triangle,3=sinc
  uint32_t freq_mHz;      // milli-Hz
  uint32_t amp_mVpp;      // mVpp
  int32_t  offset_mV;     // mV (signed)
  int32_t  phase_mdeg;    // milli-deg (signed)
  uint8_t  channel;       // 0=A, 1=B
};
struct MapConfig { float v_min = -5.0f; float v_max = +5.0f; };

// ---- forward decls (implemented in wavegen/fpga_spi) ----
uint32_t dds_ftw(double fout_hz, double fclk_hz);
void stream_set_reset_counter(uint8_t channel, uint16_t reset_val, void (*emit5)(const uint8_t* frame5));
void stream_set_phase_increment(uint8_t channel, uint32_t ftw32,     void (*emit5)(const uint8_t* frame5));
void stream_lut_frames(const StdParams& p, const MapConfig& mc,      void (*emit5)(const uint8_t* frame5));
uint16_t sample_code_at(uint32_t i, const StdParams& p, const MapConfig& mc);
double   code_to_volts_preview(uint16_t code, const MapConfig& mc);
void fpga_stream_start();
void fpga_stream_end();
void fpga_emit5(const uint8_t* frame5);

// ---------- BLE UUIDs ----------
static BLEUUID SERVICE_UUID("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
static BLEUUID RX_UUID     ("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
static BLEUUID TX_UUID     ("6e400003-b5a3-f393-e0a9-e50e24dcca9e");

// ---------- Logging ----------
static bool g_quiet = false;
template <typename... Args> static inline void QPRINT(Args&&... a){ if(!g_quiet) Serial.print(std::forward<Args>(a)...); }
template <typename... Args> static inline void QPRINTLN(Args&&... a){ if(!g_quiet) Serial.println(std::forward<Args>(a)...); }

// ---------- BLE globals ----------
static BLECharacteristic* txChar = nullptr;
static bool g_isAdvertising = false;

// ---------- ARB session state (kept from older code; harmless if unused) ----------
static const size_t SRC_FULL = 65536;
static int16_t* g_lut = nullptr;
static uint8_t* g_bitmap = nullptr;
static size_t   g_capacity = 0;
static uint32_t g_unique_received = 0;
static bool     g_plottedOnce     = false;

struct ParsedStd {
  uint8_t  version=0, msgType=0;
  uint16_t seq=0;
  uint8_t  shape=0;
  uint32_t freq_mHz=0;
  uint16_t amp_mVpp=0;
  int32_t  offset_mV=0;
  int32_t  phase_mdeg=0;
  uint8_t  channel=0;
};
struct ArbMeta {
  uint32_t freq_mHz=0;
  uint16_t amp_mVpp=0;
  int32_t  offset_mV=0;
  int32_t  phase_mdeg=0;
  uint8_t  channel=0;
  uint16_t seq=0;
  bool     active=false;
} g_meta;
static int16_t g_q15_min =  32767, g_q15_max = -32768;

// ---------- utils ----------
static void hexDump(const uint8_t* p, size_t n, const char* tag) {
  QPRINT(tag); QPRINT(" ["); QPRINT(n); QPRINTLN(" bytes]:");
  for (size_t i = 0; i < n; ++i) {
    if ((i % 16) == 0) QPRINT("  ");
    if (p[i] < 16) QPRINT('0');
    QPRINT(String(p[i], HEX)); QPRINT(' ');
    if ((i % 16) == 15 || i + 1 == n) QPRINTLN("");
  }
}
static uint16_t rd_u16_le(const uint8_t* p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t rd_u32_le(const uint8_t* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static int32_t  rd_i32_le(const uint8_t* p) { return (int32_t)rd_u32_le(p); }
static const char* shapeName(uint8_t c){switch(c){case 0:return "sine";case 1:return "square";case 2:return "triangle";case 3:return "sinc";default:return "unknown";}}
static const char* channelName(uint8_t c){switch(c){case 0:return "A";case 1:return "B";default:return "?";}}

// ---------- parsing ----------
static bool parseStd32(const uint8_t* buf, size_t len, ParsedStd& out) {
  if (len != 32 || buf[0] != 0x01 || buf[1] != 0x00) return false;
  out.version = buf[0]; out.msgType = buf[1]; out.seq = rd_u16_le(buf+2);
  size_t i=4;
  while (i+2 <= len) {
    uint8_t T = buf[i], L = buf[i+1]; i += 2;
    if (i+L > len) return false; const uint8_t* V = buf + i;
    switch (T) {
      case 0x01: if (L!=1) return false; out.shape = V[0]; break;
      case 0x02: if (L!=4) return false; out.freq_mHz = rd_u32_le(V); break;
      case 0x03: if (L!=2) return false; out.amp_mVpp = rd_u16_le(V); break;
      case 0x04: if (L!=4) return false; out.offset_mV = rd_i32_le(V); break;
      case 0x05: if (L!=4) return false; out.phase_mdeg = rd_i32_le(V); break;
      case 0x06: if (L!=1) return false; out.channel = V[0]; break;
    }
    i += L; if (i == len) break;
  }
  return true;
}
static bool parseArbMeta(const uint8_t* buf, size_t len, ArbMeta& m) {
  if (len != 32 || buf[0] != 0x01 || buf[1] != 0x01) return false;
  m.seq = rd_u16_le(buf+2); size_t i=4;
  while (i+2 <= len) {
    uint8_t T = buf[i], L = buf[i+1]; i+=2;
    if (i+L > len) return false; const uint8_t* V = buf+i;
    switch (T) {
      case 0x02: if (L!=4) return false; m.freq_mHz = rd_u32_le(V); break;
      case 0x03: if (L!=2) return false; m.amp_mVpp = rd_u16_le(V); break;
      case 0x04: if (L!=4) return false; m.offset_mV = rd_i32_le(V); break;
      case 0x05: if (L!=4) return false; m.phase_mdeg = rd_i32_le(V); break;
      case 0x06: if (L!=1) return false; m.channel = V[0]; break;
      default: break;
    }
    i += L; if (i == len) break;
  }
  return true;
}
struct ArbBlockHdr { uint16_t start_idx; uint16_t count; };
static bool parseArbDataHeader(const uint8_t* buf, size_t len, uint16_t& seq, uint8_t& T, uint8_t& L) {
  if (len < 6 || buf[0] != 0x01 || buf[1] != 0x02) return false;
  seq = rd_u16_le(buf+2); T = buf[4]; L = buf[5];
  return (T == 0x20 && L >= 4);
}

// ---------- ARB bitmap helpers (safe even if ARB not used) ----------
static inline bool testBit(uint32_t idx){ return (g_bitmap[idx>>3] >> (idx & 7)) & 1; }
static inline void setBit (uint32_t idx){ g_bitmap[idx>>3] |= (uint8_t)(1u << (idx & 7)); }
static inline uint32_t mapSrcToDst(uint32_t srcIndex){
  uint64_t num = (uint64_t)srcIndex * (uint64_t)g_capacity;
  uint32_t dst = (uint32_t)(num / (uint64_t)SRC_FULL);
  if (dst >= g_capacity) dst = g_capacity - 1;
  return dst;
}
static void applyArbBlock(uint16_t start_idx, uint16_t count, const int16_t* samples) {
  if (!g_lut || !g_bitmap || g_capacity == 0) return;
  uint32_t prevDst = UINT32_MAX;
  for (uint16_t i=0;i<count;++i){
    uint32_t src = (uint32_t)start_idx + i; if (src >= SRC_FULL) break;
    uint32_t dst = mapSrcToDst(src); if (dst == prevDst) continue;
    int16_t s = samples[i];
    if (s < g_q15_min) g_q15_min = s; if (s > g_q15_max) g_q15_max = s;
    g_lut[dst] = s; if (!testBit(dst)) { setBit(dst); ++g_unique_received; }
    prevDst = dst;
  }
}
static void maybePrintDone() {
  if (g_capacity == 0) return;
  if (g_unique_received >= g_capacity && !g_plottedOnce) {
    QPRINT("** [ARB DONE] LUT ready. cap="); QPRINT(g_capacity);
    QPRINT(" f="); QPRINT(g_meta.freq_mHz/1000.0,3); QPRINT(" Hz, Vpp=");
    QPRINT(g_meta.amp_mVpp/1000.0,3); QPRINT(" V, offset=");
    QPRINT(g_meta.offset_mV/1000.0,3); QPRINT(" V, phase=");
    QPRINT(g_meta.phase_mdeg/1000.0,3); QPRINT(" deg, ch=");
    QPRINTLN((g_meta.channel==0)?"A":(g_meta.channel==1)?"B":"?");
    g_plottedOnce = true;
  }
}

// ---------- frame reassembler (single copy) ----------
static uint8_t g_buf[320];
static size_t  g_have = 0, g_need = 0;

static int findHeaderIdx(const uint8_t* d, int n){
  for (int i=0;i+1<n;++i)
    if (d[i]==0x01 && (d[i+1]==0x00 || d[i+1]==0x01 || d[i+1]==0x02))
      return i;
  return -1;
}
static void resetAsm(){ g_have=0; g_need=0; }

// ---------- processFrame ----------
static const uint32_t PREVIEW_STEP = 1000;

static void processFrame(const uint8_t* f, size_t n) {
  uint8_t msg = f[1];

  if (msg == 0x00) { // Standard waveform
    ParsedStd p{};
    if (!parseStd32(f, n, p)) { QPRINTLN("Std parse failed."); return; }

    QPRINTLN("[PKT] Parsed standard waveform");
  
    QPRINT("  shape="); QPRINT(p.shape); QPRINT(" ("); QPRINT(shapeName(p.shape)); QPRINTLN(")");
    QPRINT("  f=");     QPRINT(p.freq_mHz / 1000.0, 3); QPRINTLN(" Hz");
    QPRINT("  Vpp=");   QPRINT(p.amp_mVpp   / 1000.0, 3); QPRINTLN(" V");
    QPRINT("  ofs=");   QPRINT(p.offset_mV  / 1000.0, 3); QPRINTLN(" V");
    QPRINT("  ph=");    QPRINT(p.phase_mdeg / 1000.0, 3); QPRINTLN(" deg");
    QPRINT("  ch=");    QPRINTLN(channelName(p.channel));

    StdParams sp{ p.shape, p.freq_mHz, p.amp_mVpp, p.offset_mV, p.phase_mdeg, p.channel };
    MapConfig mc; mc.v_min = -5.0f; mc.v_max = +5.0f;

    static constexpr double FPGA_DDS_FCLK_HZ = 1000000.0; // 1 MSPS example
    const uint32_t ftw = dds_ftw((double)sp.freq_mHz / 1000.0, FPGA_DDS_FCLK_HZ);

    // ---- PREVIEW: FTW and block stats (0..65535 grouped by 1000) ----
    QPRINT("[FTW] "); QPRINT((unsigned long)ftw);
    QPRINT(" (0x"); Serial.print(ftw, HEX); QPRINTLN(")");

    uint32_t printed = 0;
    for (uint32_t start = 0; start < 65536; start += PREVIEW_STEP) {
      uint32_t end = start + PREVIEW_STEP - 1; if (end > 65535) end = 65535;
      uint16_t bmin = 0xFFFF, bmax = 0x0000;
      uint32_t imin = start, imax = start;
      for (uint32_t i = start; i <= end; ++i) {
        uint16_t c = sample_code_at(i, sp, mc);
        if (c < bmin) { bmin = c; imin = i; }
        if (c > bmax) { bmax = c; imax = i; }
      }
      QPRINT("[BLK "); QPRINT(start); QPRINT("-"); QPRINT(end); QPRINT("] ");
      QPRINT("min="); QPRINT(bmin); QPRINT(" @"); QPRINT(imin);
      QPRINT(" ("); QPRINT(code_to_volts_preview(bmin, mc), 4); QPRINT(" V)  ");
      QPRINT("max="); QPRINT(bmax); QPRINT(" @"); QPRINT(imax);
      QPRINT(" ("); QPRINT(code_to_volts_preview(bmax, mc), 4); QPRINTLN(" V)");

      if ((++printed % 4) == 0) {
        yield();
        #ifdef ARDUINO_ARCH_ESP32
          esp_task_wdt_reset();
        #endif
      }
    }
    QPRINTLN("[PREVIEW] Done");

    // Give scheduler a moment before any heavy SPI work
    yield();
    #ifdef ARDUINO_ARCH_ESP32
      esp_task_wdt_reset();
    #endif

#if ENABLE_SPI_STREAM
    fpga_stream_start();
    stream_set_reset_counter(sp.channel, /*reset*/0, fpga_emit5);
    stream_set_phase_increment(sp.channel, ftw, fpga_emit5);
    stream_lut_frames(sp, mc, fpga_emit5);  // has periodic yields inside
    fpga_stream_end();
    QPRINTLN("[SPI] FTW + 64k LUT streamed (3-bit opcodes).");
#else
    QPRINTLN("[SPI] Skipped (ENABLE_SPI_STREAM=0).");
#endif

    // optional ack to client
    if (txChar) {
      std::string ok = "ack:std";
      txChar->setValue(ok);
      txChar->notify();
    }

  } else if (msg == 0x01) {
    ArbMeta m{};
    if (!parseArbMeta(f, n, m)) { QPRINTLN("ARB META parse failed."); return; }

    if (g_lut && g_capacity) memset(g_lut, 0, g_capacity * sizeof(int16_t));
    if (g_bitmap && g_capacity) memset(g_bitmap, 0, (g_capacity + 7) / 8);
    g_unique_received = 0; g_q15_min = 32767; g_q15_max = -32768;
    g_meta = m; g_meta.active = true; g_plottedOnce = false;

    QPRINT("[PKT] Parsed arbitrary META | dest-capacity="); QPRINTLN((int)g_capacity);

  } else if (msg == 0x02) {
    uint16_t seq; uint8_t T, L;
    if (!parseArbDataHeader(f, n, seq, T, L)) { QPRINTLN("ARB DATA header parse failed."); return; }
    if ((size_t)(6 + L) != n) { QPRINTLN("ARB DATA length mismatch."); return; }
    const uint8_t* V = f + 6; if (L < 4) { QPRINTLN("ARB DATA L<4"); return; }

    ArbBlockHdr bh; bh.start_idx = rd_u16_le(V+0); bh.count = rd_u16_le(V+2);
    if (L != (uint8_t)(4 + 2 * bh.count)) {
      QPRINT("ARB DATA bad L vs count. L="); QPRINT(L); QPRINT(" count="); QPRINTLN(bh.count); return;
    }
    const int16_t* samples = (const int16_t*)(V + 4);

    int16_t bmin=32767, bmax=-32768;
    for (uint16_t i=0;i<bh.count;++i){ int16_t s=samples[i]; if(s<bmin)bmin=s; if(s>bmax)bmax=s; }
    QPRINT("[PKT] Parsed arbitrary DATA | Seq="); QPRINT(seq);
    QPRINT(" srcIdx="); QPRINT(bh.start_idx);
    QPRINT(" count=");  QPRINT(bh.count);
    QPRINT(" q15[min="); QPRINT(bmin);
    QPRINT(" max=");     QPRINT(bmax); QPRINTLN("]");

    if (!g_meta.active){ QPRINTLN("[ARB] Warning: DATA before META"); }
    if (!g_lut || !g_bitmap || g_capacity == 0){ QPRINTLN("[ARB] ERROR: Buffers not allocated."); return; }

    applyArbBlock(bh.start_idx, bh.count, samples);

    QPRINT("[ARB LUT-BLOCKED] dest-capacity="); QPRINT((int)g_capacity);
    QPRINT(" total_received="); QPRINT(g_unique_received);
    QPRINTLN("/" + String((int)g_capacity));

    maybePrintDone();

  } else {
    QPRINT("Unknown MsgType="); QPRINTLN(msg);
  }
}


// ---------- reassembler feeder (keep single copy of globals above) ----------
static void feedAsm(const uint8_t* d, int n) {
  int off = 0;
  while (off < n) {
    if (g_have == 0) {
      int h = findHeaderIdx(d + off, n - off);
      if (h < 0) return;
      off += h;
    }
    if (g_need > 0) {
      int toCopy = min((int)(g_need - g_have), n - off);
      memcpy(g_buf + g_have, d + off, toCopy);
      g_have += toCopy; off += toCopy;
      if (g_have == g_need) { hexDump(g_buf, g_need, "RX frame"); processFrame(g_buf, g_need); resetAsm(); }
      continue;
    }
    if (g_have < 4) {
      int need = 4 - (int)g_have;
      int toCopy = min(need, n - off);
      memcpy(g_buf + g_have, d + off, toCopy);
      g_have += toCopy; off += toCopy;
      if (g_have < 4) continue;
    }
    uint8_t msg = g_buf[1];
    if (msg == 0x00 || msg == 0x01) { g_need = 32; continue; }
    if (msg == 0x02) {
      if (g_have < 6) {
        int need = 6 - (int)g_have;
        int toCopy = min(need, n - off);
        memcpy(g_buf + g_have, d + off, toCopy);
        g_have += toCopy; off += toCopy;
        if (g_have < 6) continue;
      }
      uint8_t T = g_buf[4], L = g_buf[5];
      if (T != 0x20) { int h2 = findHeaderIdx(d + off, n - off); if (h2 < 0) { resetAsm(); return; } resetAsm(); off += h2; continue; }
      g_need = 4 + 2 + L; if (g_need > sizeof(g_buf)) { QPRINTLN("Frame too large; dropping."); resetAsm(); continue; }
      continue;
    }
    int h2 = findHeaderIdx(d + off, n - off);
    if (h2 < 0) { resetAsm(); return; }
    resetAsm(); off += h2;
  }
}

// ---------- BLE callbacks ----------
static void handleWriteCommon(BLECharacteristic* c, const char* which) {
  const std::string s = c->getValue();
  const uint8_t* data = reinterpret_cast<const uint8_t*>(s.data());
  const size_t   len  = s.size();
  QPRINTLN(">>> onWrite HIT");
  hexDump(data, len, which);
  feedAsm(data, (int)len);

  if (txChar) {
    std::string ack = "ack:" + std::to_string(len);
    txChar->setValue(ack);
    txChar->notify();
    QPRINTLN("→ Sent ack to client");
  }
}
class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override { handleWriteCommon(c, "RX write"); }
};
class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* ) override { QPRINTLN("Central connected."); g_isAdvertising = false; }
  void onDisconnect(BLEServer* ) override {
    QPRINTLN("Central disconnected. Restart advertising.");
    BLEDevice::startAdvertising(); g_isAdvertising = true; QPRINTLN("✅ Advertising (connectable) as ESP32-NUS");
    resetAsm();
  }
};

// ---------- ARB allocation helper (safe if you never use ARB) ----------
static bool allocWithFallback() {
  const size_t tries[] = {16384, 8192, 4096};
  for (size_t cap : tries) {
    yield();
    size_t lutBytes = cap * sizeof(int16_t);
    size_t bmpBytes = (cap + 7) / 8;

    if (g_lut)    { heap_caps_free(g_lut);    g_lut = nullptr; }
    if (g_bitmap) { heap_caps_free(g_bitmap); g_bitmap = nullptr; }

    g_lut    = (int16_t*) heap_caps_malloc(lutBytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!g_lut)    g_lut    = (int16_t*) heap_caps_malloc(lutBytes, MALLOC_CAP_8BIT);
    yield();
    g_bitmap = (uint8_t*) heap_caps_malloc(bmpBytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!g_bitmap) g_bitmap = (uint8_t*) heap_caps_malloc(bmpBytes, MALLOC_CAP_8BIT);

    if (g_lut && g_bitmap) {
      g_capacity = cap; memset(g_lut, 0, lutBytes); memset(g_bitmap, 0, bmpBytes);
      QPRINT("[MEM] ARB capacity set to "); QPRINT((int)g_capacity); QPRINTLN(" samples.");
      return true;
    }
  }
  QPRINTLN("[MEM] No ARB buffer allocated; continuing without ARB.");
  g_capacity = 0;
  return true;
}

// ---------- public init/loop ----------
void ble_init() {
  allocWithFallback();  // don't fail boot if missing

  BLEDevice::init("ESP32-NUS");
  delay(10);
  Serial.printf("BLE init OK. MAC: %s\n", BLEDevice::getAddress().toString().c_str());

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService* svc = server->createService(SERVICE_UUID);

  txChar = svc->createCharacteristic(TX_UUID, BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ);
  txChar->addDescriptor(new BLE2902());

  BLECharacteristic* rxChar = svc->createCharacteristic(RX_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  rxChar->setCallbacks(new RxCallbacks());

  svc->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  BLEAdvertisementData advData;   advData.setName("ESP32-NUS"); advData.setCompleteServices(SERVICE_UUID); adv->setAdvertisementData(advData);
  BLEAdvertisementData scanResp;  scanResp.setName("ESP32-NUS"); adv->setScanResponseData(scanResp);
  adv->setScanResponse(true);
  adv->setMinPreferred(0x06);
  adv->setMinPreferred(0x00);
  BLEDevice::startAdvertising();
  g_isAdvertising = true;
}


